<?php
global $wpdb;
if(isset($_GET['floorplan']) && $_GET['floorplan'] != "")
	$floorplan = $_GET['floorplan'];
else
{
	echo "Invalid Url";
	die;
}

$table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
$sql_search = "select * from $table_name where api_response_id = '".$floorplan."'";
$search_res = $wpdb->get_row($sql_search);

///////////////////////////////////
$unit_status_json = '{}';
if(file_exists(dirname(__FILE__).'/../unit_status.json'))
	$unit_status_json = file_get_contents(dirname(__FILE__).'/../unit_status.json');
$unit_status_array = json_decode($unit_status_json,true);

$floorPlanID = $floorplan;
$moveindate = date('Y-m-d');
$unit_lists_json = '{}';
if(file_exists(dirname(__FILE__).'/../first_load_response.json'))
	$unit_lists_json = file_get_contents(dirname(__FILE__).'/../first_load_response.json');
$unit_lists_array = json_decode($unit_lists_json);
$max_day = CALENDAR_UPCOMING_DAYS; ////to get max date
$maxDate = date('Y-m-d', strtotime("+".$max_day." day", strtotime(date('Y-m-d'))));
//
$rowCount = 0;
$result =array();
$str = '';
if($unit_lists_array)
  {
  	//print_r($unit_lists_array);
      foreach ($unit_lists_array as $key => $unit_lists) 
      {

        if($key == 'floor_plan_'.$floorPlanID)
        {
          if(isset($unit_lists->{'@attributes'})){
            $fetched_date = $unit_lists->{'@attributes'}->available_date;
          } else {
            $fetched_date = '';
          }
          // print_r($unit_lists->ListResponse->ListResult->UnitObject);
           //print_r($fetched_date);
           
          if($fetched_date)
          {
          	//print_r($maxDate);
             //if(strtotime($maxDate) <= strtotime($fetched_date))
             //{ 

                if(isset($unit_lists->ListResponse->ListResult->UnitObject))
                {

                    $str .='
                              <div class="rrac_listAvailableUnit">
                                <table class="table">
                                  <tr>
                                    <th>Unit Number</th>
                                    
                                    <th>Starting At</th>
                                    <th>Deposit</th>
                                    <th>Availability</th>
                                    <th>Status Update</th>
                                  </tr>';

                    if(is_array($unit_lists->ListResponse->ListResult->UnitObject))
                    {
                    	
                        foreach($unit_lists->ListResponse->ListResult->UnitObject as $res)
                        {
                        	$unitStaus = 1;
                        	if(isset($unit_status_array[$floorPlanID.'-'.$res->Address->UnitNumber]))
                    		{
                    			$unitStaus = $unit_status_array[$floorPlanID.'-'.$res->Address->UnitNumber];
                    		}
  							

                          //$moveindateResultNext = date('Y-m-d', strtotime("+".RESULT_SHOW_NEXT_DAYS." day", strtotime($moveindate)));
                          $moveindateResultPrev = date('Y-m-d', strtotime("-".RESULT_SHOW_PREV_DAYS." day", strtotime($moveindate)));
                          $MadeReadyDate = date('Y-m-d', strtotime($res->Availability->MadeReadyDate));

                          if($MadeReadyDate >= $moveindateResultPrev && $MadeReadyDate <= $maxDate)
                          {
                          	
                            if(date('Y-m-d',strtotime($res->Availability->MadeReadyDate)) <= date('Y-m-d')) 
                              $availableData = 'Available Now'; 
                            else 
                              $availableData = $res->Availability->MadeReadyDate;

                            $startingAtPrice = $res->BaseRentAmount;
                            if(isset($res->rentMatrix->row))
                            {
                                //echo "<pre>";
                                $rentMatrix = json_decode(json_encode($res->rentMatrix->row), true);
                                $startingAtPrice =  $rentMatrix['@attributes']['MinRent'];
                                //print_r($rentMatrix['@attributes']);
                            }
                              
                            $str .='<tr>
                                  <td>'.$res->Address->UnitNumber.'</td>
                                  
                                  <td>$'.number_format((float)$startingAtPrice,2).'</td>
                                  <td>$'.$res->DepositAmount.'</td>
                                  <td>'.$availableData.'</td>
                                  <td>';
                                  if($unitStaus == 1)
                                  	$str .='<a class="btn btn-sm btn-success" title="Click to Hide" href="javascript:;" onclick="goto_change_status(\''.$floorPlanID.'-'.$res->Address->UnitNumber.'\',\'0\')">Show</a></td>';
                                  else
                                  	$str .='<a class="btn btn-sm btn-danger" title="Click to Show" href="javascript:;" onclick="goto_change_status(\''.$floorPlanID.'-'.$res->Address->UnitNumber.'\',\'1\')">Hide</a>';

                                $str .='</td>
                                </tr>';
                            $rowCount++;
                          } 
                        }
                    }
                    else
                    {

                      $res = $unit_lists->ListResponse->ListResult->UnitObject;

                      $unitStaus = 1;
	                  if(isset($unit_status_array[$floorPlanID.'-'.$res->Address->UnitNumber]))
	            	  {
	            		$unitStaus = $unit_status_array[$floorPlanID.'-'.$res->Address->UnitNumber];
	            	  }

                      $moveindateResultNext = date('Y-m-d', strtotime("+".RESULT_SHOW_NEXT_DAYS." day", strtotime($moveindate)));
                      $moveindateResultPrev = date('Y-m-d', strtotime("-".RESULT_SHOW_PREV_DAYS." day", strtotime($moveindate)));
                      $MadeReadyDate = date('Y-m-d', strtotime($res->Availability->MadeReadyDate));

                      if($MadeReadyDate >= $moveindateResultPrev && $MadeReadyDate <= $maxDate)
                      {
                        if(date('Y-m-d',strtotime($res->Availability->MadeReadyDate)) <= date('Y-m-d')) 
                          $availableData = 'Available Now'; 
                        else 
                          $availableData = $res->Availability->MadeReadyDate;

                        $startingAtPrice = $res->BaseRentAmount;
                        if(isset($res->rentMatrix->row))
                        {
                            //echo "<pre>";
                            $rentMatrix = json_decode(json_encode($res->rentMatrix->row), true);
                            $startingAtPrice =  $rentMatrix['@attributes']['MinRent'];
                            //print_r($rentMatrix['@attributes']);
                        }
                          
                        $str .='<tr>
                              <td>'.$res->Address->UnitNumber.'</td>
                              
                              <td>$'.number_format((float)$startingAtPrice,2).'</td>
                              <td>$'.$res->DepositAmount.'</td>
                              <td>'.$availableData.'</td>
                              <td>';
                                  if($unitStaus == 1)
                                  	$str .='<a title="Click to Hide" href="javascript:;" onclick="goto_change_status(\''.$floorPlanID.'-'.$res->Address->UnitNumber.'\',\'0\')">Show</a></td>';
                                  else
                                  	$str .='<a title="Click to Show" href="javascript:;" onclick="goto_change_status(\''.$floorPlanID.'-'.$res->Address->UnitNumber.'\',\'1\')">Hide</a>';

                                $str .='
                                	</td>
                                </tr>';
                      }

                      $rowCount = 1;

                    }


                    $str .='</table></div>';
                }
                
             //}
          }
      
        }
        
      }
  }

?>
<div class="col-md-12 rrac_app_list_page rrac_admin_page">
	<div class="col-md-12">&nbsp;</div>
	<a class="btn btn-sm btn-warning" href="<?php echo admin_url('admin.php?page=floor_plan_type') ?>">Back</a>
	<h3><?php echo RRAC_PLUGIN_NAME;?> - Available Unit Of <b><?php echo $search_res->marketing_type?></b></h3>
	<hr/>
	<div class="alert alert-success" style="display: none;">
  		<button type="button" class="close">x</button>
	  	<strong>Success!</strong> Credential saved successfully.
	</div>

	<div class="col-md-12">
		<h4>Unit Lists:</h4>
		
		<div class="col-md-12">&nbsp;</div>
		
			<div class="appListingSection unitListingSection">
			<?php  echo $str; ?>
			</div>
		
	</div>
</div>
<?php global $ajax_url;?>
<script type="text/javascript">
	function goto_change_status(floor_unit , status)
	{
		if(confirm('Are you sure to change status of this item?'))
		{
			jQuery.ajax({
				url:ajaxurl,
				data:'floor_unit='+floor_unit+'&status='+status+'&action=rrac_unitStatusChange',
				type:'POST',
				cache:false,
				success:function(data){
					alert('Item status change successfully.');
					window.location.reload();						
				}
			})
			return false;
		}
	}
</script>


