<?php
global $wpdb;
$sql_group = "";
if(isset($_GET['group_id']) && $_GET['group_id'] != "")
{
	$sql_group = " and floorplan_group_id = ".$_GET['group_id'];
}
$table_name_group = $wpdb->prefix . 'rrac_floorplan_group';
$table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
$sql_search = "select $table_name.*,$table_name_group.group_name from $table_name left join $table_name_group on $table_name.floorplan_group_id = $table_name_group.id where 1 $sql_group";
$search_res = $wpdb->get_results($sql_search);
?>
<div class="col-md-12 rrac_app_list_page rrac_admin_page">
	<h3><?php echo RRAC_PLUGIN_NAME;?> - Floor Plan Type</h3>
	<hr/>
	<div class="alert alert-success" style="display: none;">
  		<button type="button" class="close">x</button>
	  	<strong>Success!</strong> Credential saved successfully.
	</div>

	<div class="col-md-12">
		<h4>Floor Plan Lists:</h4>
		<div class="col-md-12">&nbsp;</div>
		<div class="col-md-12 text-right">
			<a class="btn btn-danger" href="javascript:;" id="delSelected">Delete Selected Item</a>
			<a class="btn btn-success" href="javascript:;" id="syncApartment">Sync</a>
		</div>
		<div class="col-md-12">&nbsp;</div>
		<form action="javascript:;" method="POST" id="apartmentListFrm">
			<div class="appListingSection">
			<table class="table" id="rrac_apartList">
			    <thead>
					<tr>
						<th><input type="checkbox" id="selectall" class="css-checkbox" name="selectall"/></th>
						<th>Floor Plan ID</th>
						<th>Name</th>
						<th>Code</th>
						<th>Group</th>
						<th>Bedroom</th>
						<th>Bathroom</th>
						<th>Image</th>
						<th>Unit Available</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
			    </thead>
			    <tbody>
					<?php
					foreach($search_res as $search_re) {
						$total_available = get_available_unit_count($search_re->api_response_id);
					?>
					<tr>
						<td><input type="checkbox" class="checkboxall" name="deleteItem[]" value="<?php echo $search_re->id;?>"/></td>
						<td><?php echo $search_re->api_response_id;?></td>
						<td><?php echo $search_re->marketing_type;?></td>
						<td><?php echo $search_re->floorplan_code;?></td>
						<td><?php echo $search_re->group_name;?></td>
						<td><?php echo $search_re->bedroom;?></td>
						<td><?php echo $search_re->bathroom;?></td>
						<td><?php if($search_re->image != "") {echo '<img src="'.$search_re->image.'" width="100" />';} ?></td>
						<td><?php 
							if($total_available['count']>0) 
							{
								$rrac_display_max_available_unit = get_option('rrac_display_max_available_unit');
								if($rrac_display_max_available_unit == '') 
									$show_available = $total_available['count'];
								else if($rrac_display_max_available_unit < $total_available['count'])
									$show_available = $rrac_display_max_available_unit;
								else
									$show_available = $total_available['count'];
								echo "<a onclick=\"return false;\" href=\"".admin_url('admin.php?page=available_unit_list&floorplan='.$search_re->api_response_id)."\" style=\"color:white; cursor:default; background:green;padding:5px;border-radius:3px;\" data-title=\"View Available Unit\">".$show_available." Available</a>"; 
							}
							else 
								//echo "<span style=\"color:red\">Not Available</span>";
							?>
									
						</td>
						<td><?php echo $search_re->status==1?'Active':'Inactive';?></td>
						<td>
							<a class="btn btn-xs btn-primary" href="<?php echo admin_url('admin.php?page=floor_plan_type_edit&id='.$search_re->id) ?>">Edit</a>
							<a class="btn btn-xs btn-danger" onclick="delete_this('<?php echo $search_re->id ?>');" href="javascript:;">Delete</a>
						</td>
					</tr>
					<?php 
					}
					?>
				</tbody>
			</table>
			</div>
		</form>
	</div>
</div>
<?php global $ajax_url;?>
<script>
	var ajaxurl = '<?php echo $ajax_url;?>';
	var plugin_url = '<?php echo plugins_url('/repli_realpage_apartment_sync');?>';
	jQuery(document).ready(function(){
		var append_string='<div class="rrac_loader_container"><div class="img_section"><img src="'+plugin_url+'/assets/images/loading.gif" width="100%" alt="" /></div></div>';
		jQuery('body').prepend(append_string);

		////////////////////////
		jQuery('#syncApartment').on('click', function(){
			jQuery('.rrac_loader_container').show();
			jQuery.ajax({
				url:ajaxurl,
				data:'action=rrac_syncApartment',
				type:'POST',
				cache:false,
				success:function(data){
					//console.log(data);
					//alert(data);
					var res = jQuery.parseJSON(data);
					if(res.status == 1)
					{
						alert(res.message);
					}
					else 
					{
						alert(res.message);
					}
					jQuery('.rrac_loader_container').hide();
					window.location.reload();						
				}
			})
			return false;
		});

		jQuery('.alert-success .close').on('click',function(){
	        jQuery(this).closest('.alert').slideUp();
	   });
	    /////////////Data Table
		jQuery('#rrac_apartList').DataTable({
			'order':[],
            'columnDefs': [{
                "targets": [-1,-3,0],
                "orderable": false
            }]
		});
		/////////////delete selected items
		jQuery('#delSelected').on('click', function(){
			var flag = false;
			jQuery('.checkboxall').each(function(){
	            if(this.checked){
	            	flag = true;
	            	return;
	            }
	         });
			if(flag)
			{
				if(confirm('Are you sure to delete selected items?'))
				{
					var data =jQuery('#apartmentListFrm').serialize();

					jQuery.ajax({
						url:ajaxurl,
						data:data+'&action=rrac_delSelectedApartment',
						type:'POST',
						cache:false,
						success:function(data){
							alert('Items deleted successfully.');
							window.location.reload();						
						}
					});
				}
				
			}
			else
			{
				alert('Please select atleast one item to delete.');
			}
			
			return false;
		});
			
	});

	function delete_this(idd)
	{
		if(confirm('Are you sure to delete this item?'))
		{
			jQuery.ajax({
				url:ajaxurl,
				data:'idd='+idd+'&action=rrac_delApartment',
				type:'POST',
				cache:false,
				success:function(data){
					alert('Item deleted successfully.');
					window.location.reload();						
				}
			})
			return false;
		}
	}

	jQuery(document).ready(function(){
		jQuery(".checkboxall").prop('checked', false);
		jQuery("#selectall").prop('checked', false);
		jQuery("#selectall").click(function(){
	        if(this.checked){
	            jQuery('.checkboxall').each(function(){
	                jQuery(".checkboxall").prop('checked', true);
	            })
	        }else{
	            jQuery('.checkboxall').each(function(){
	                jQuery(".checkboxall").prop('checked', false);
	            })
	        }
	    });


	    jQuery(".checkboxall").click(function(){
	    	var flag = true;
	    	jQuery('.checkboxall').each(function(){
	            if(this.checked){
	            }
	            else
	            {
	            	flag = false;
	            	return;
	            }
	         });
	    	if(flag)
	    	{
	    		jQuery("#selectall").prop('checked', true);
	    	}
	    	else
	    	{
	    		jQuery("#selectall").prop('checked', false);
	    	}
	    });
	});
		
</script>

