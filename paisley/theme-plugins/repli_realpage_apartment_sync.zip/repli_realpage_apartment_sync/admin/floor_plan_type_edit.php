<?php
global $wpdb;
$table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
$sql_search = "select * from $table_name where id=".$_GET['id'];
$search_res = $wpdb->get_row($sql_search);


// This will enqueue the Media Uploader script
wp_enqueue_media();
?>
<div class="col-md-12 rrac_app_edit_page rrac_admin_page">
	<h3><?php echo RRAC_PLUGIN_NAME;?> - Floor Plan Type</h3>
	<hr/>
	<div class="alert alert-success" style="display: none;">
  		<button type="button" class="close">x</button>
	  	<strong>Success!</strong> Credential saved successfully.
	</div>

	<div class="col-md-12">
		<h4>Floor Plan Edit:</h4>
		<div class="col-md-12">&nbsp;</div>
		<form action="javascript:;" name="rrac_Apartment_type" id="rrac_Apartment_type" method="post" enctype="multipart/form-data">
			<input type="hidden" name="idd" value="<?php echo $search_res->id; ?>">
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Floor Plan Type:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="marketing_type" required="" value="<?php echo $search_res->marketing_type; ?>" ></div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Group:</label></div>
					<div class="col-md-9">
						<select name="floorplan_group_id" class="form-control" required="">
							<option value="">--Select--</option>
							<?php
							$table_group = $wpdb->prefix . 'rrac_floorplan_group';
							$sql_group = "select * from $table_group where status=1";
							$search_group = $wpdb->get_results($sql_group);
							foreach($search_group as $search_grp)
							{
								?>
								<option value="<?php echo $search_grp->id;?>" <?php if(isset($search_res->floorplan_group_id) && $search_res->floorplan_group_id == $search_grp->id) echo "selected"; ?>><?php echo $search_grp->group_name;?></option>
								<?php
							}
							?>
						</select>
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Tag Line:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="tagline" value="<?php echo $search_res->tagline; ?>" ></div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Bedroom:</label></div>
					<div class="col-md-9"><input type="number" class="form-control" name="bedroom" required="" value="<?php echo $search_res->bedroom; ?>" ></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Bathroom:</label></div>
					<div class="col-md-9"><input type="number" class="form-control" name="bathroom" required="" value="<?php echo $search_res->bathroom; ?>" ></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Size(SQFT):</label></div>
					<div class="col-md-9"><input type="number" class="form-control" name="size" required="" value="<?php echo $search_res->size; ?>" ></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Deposit Amount:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="deposit"  value="<?php echo $search_res->deposit; ?>" ></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Min Rent:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="min_rent" required="" value="<?php echo $search_res->min_rent; ?>" ></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Max Rent:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="max_rent" required="" value="<?php echo $search_res->max_rent; ?>" ></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Lease Term Range:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="term_range"  value="<?php echo $search_res->term_range; ?>" ></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Description:</label></div>
					<div class="col-md-9"><?php wp_editor( $search_res->description, 'description' );?></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Status:</label></div>
					<div class="col-md-9">
						<input type="radio" name="status" value="1" <?php if($search_res->status == 1)echo "checked"?>> Active
						<input type="radio" name="status" value="0" <?php if($search_res->status == 0)echo "checked"?>> Inactive
					</div>
				</div>
			</div>


			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label for="image_url">Image</label></div>
				    <div class="col-md-3"><input type="button" name="upload-btn" id="upload-btn" class="button-secondary" value="Upload Image"></div>
				    <div class="col-md-3">
				    	<input type="hidden" name="image" id="image" class="regular-text" value="<?php if($search_res->image != '') {echo $search_res->image;} ?>">
				    	<div class="imgContainer"><?php if($search_res->image != "") {echo '<img src="'.$search_res->image.'" width="100" />';} ?></div>
				    </div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label for="image_url">Current Gallery Image</label></div>
				    
				    <div class="col-md-6">
				    	<div class="imgContainerCurrentGallery">
				    		<?php 
				    		if($search_res->image_gallery != "") 
				    		{
				    			$gallery_images = explode(',',$search_res->image_gallery);
				    			$count =1;
				    			foreach($gallery_images as $gallery_image){
				    				echo '<div class="image_gallery_'.$count.'">';
				    				echo '<img src="'.$gallery_image.'" width="100" />';
				    				echo '<a href="javascript:;" onclick="removeGalleryImage(\''.$gallery_image.'\' , \''.$_GET['id'].'\' , \'image_gallery_'.$count.'\')">Remove</a>';
				    				echo '</div>';
				    				$count++;
				    			}
				    		} 
				    		?>
				    				
				    	</div>
				    </div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label for="image_url">Gallery Image</label></div>
				    <div class="col-md-3"><input type="button" name="upload-gallery-btn" id="upload-gallery-btn" class="button-secondary" value="Upload Gallery Image"></div>
				    <div class="col-md-3">
				    	<input type="hidden" name="image_gallery" id="image_gallery" class="regular-text" value="">
				    	<div class="imgContainerGallery">
				    						    				
				    	</div>
				    </div>
				</div>
			</div>
			<?php
				$message_vertual_tour = "";
				$virtual_tours = array();
        		$virtual_tour = $search_res->virtual_tour;
        		if($virtual_tour != '')
        		{
        			$virtual_tours = json_decode($virtual_tour);
        			if($virtual_tours === null) 
    				{
    					$message_vertual_tour = "Invalid Vertual tour data. please update again.";
    					$virtual_tours = array();
    				}
        		}
        		//print_r($virtual_tours);
        	?>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label for="image_url">Vertual Tour</label></div>
				    <div class="col-md-6">
				    	<?php echo $message_vertual_tour; ?>
				    	<input type="radio" name="vertual_tour" id="" class="form-check-input" value="1" <?php if (count($virtual_tours) >0 )  echo "checked";?> > Yes
				    	<input type="radio" name="vertual_tour" id="" class="form-check-input" value="0" <?php if (count($virtual_tours) < 1 )  echo "checked";?>> No
				    </div>
				    
				</div>
			</div>

			<div class="row" id="vertual_tour_section">
				<div class="col-md-3">
				</div>
				<div class="col-md-9">
					<div class="control-group">
				        <div class="inc">
				        	<?php 
				        	if(count($virtual_tours) > 1)
				        	{
				        		$count = 1;
				        		foreach($virtual_tours as $virtual_trs)
				        		{
				        			
				        		?>
				        			<div class="row">
						            	<div class="col-md-9">
						                	<textarea placeholder="Enter iframe code" class="form-control" name="vertual_tour_iframe[]"><?php echo $virtual_trs; ?></textarea>
						            	</div>
						            	<?php if($count > 1)
						            	{
						            	?>
						            		<div class="col-md-3"><a href="#" class="remove_this btn btn-danger">remove</a></div>
						            	<?php 
						            	 } ?>
						            	<div class="col-md-12">&nbsp;</div>
						            </div>
				        			<?php
				        			$count++;
				        		}
				        	}
				        	else
				        	{
				        		?>
				        		<div class="row">
					            	<div class="col-md-9">
					                	<textarea placeholder="Enter iframe code" class="form-control" name="vertual_tour_iframe[]"><?php if(isset($virtual_tours[0]) && $virtual_tours[0] != "" ) echo $virtual_tours[0]; ?></textarea>
					            	</div>
					            	<div class="col-md-12">&nbsp;</div>
					            </div>
				        		<?php
				        	}
				        	?>
				            
				            
				        </div>
				        <br>
				        <button style="" class="btn btn-info" type="" id="append" name="append">
				                Add Textbox</button>
				    </div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-12  text-center"><input id="submit" type="submit" class="btn btn-primary" name="Save" value="SAVE"></div>
				</div>
			</div>
		</form>
		
	</div>
</div>
<?php global $ajax_url;?>
<script>
	var ajaxurl = '<?php echo $ajax_url;?>';
	jQuery(document).ready(function(){
		jQuery('#rrac_Apartment_type').on('submit', function(){
			var rrac_formdata = jQuery('#rrac_Apartment_type').serialize();
			jQuery.ajax({
				url:ajaxurl,
				data:rrac_formdata+'&action=rrac_Apartment_type_edit',
				type:'POST',
				cache:false,
				success:function(data){
					console.log(data);
					if(data == 1)
					{
						alert('Data updated successfully.');
						window.location.href="<?php echo admin_url('admin.php?page=floor_plan_type'); ?>";
						
					}						
				}
			})
			return false;
		});

		jQuery('.alert-success .close').on('click',function(){
	        jQuery(this).closest('.alert').slideUp();
	   });
		jQuery('#submit').mousedown( function() {
		    tinyMCE.triggerSave();
		});
	});


		
</script>



<script type="text/javascript">
jQuery(document).ready(function($){
    jQuery('#upload-btn').click(function(e) {
        e.preventDefault();
        var image = wp.media({ 
            title: 'Upload Image',
            // mutiple: true if you want to upload multiple files at once
            multiple: false,
            library : {
                    type : 'image',
                }
        }).open()
        .on('select', function(e){
            // This will return the selected image from the Media Uploader, the result is an object
            var uploaded_image = image.state().get('selection').first();
            // We convert uploaded_image to a JSON object to make accessing it easier
            // Output to the console uploaded_image
            console.log(uploaded_image);
            var image_url = uploaded_image.toJSON().url;
            // Let's assign the url value to the input field
            jQuery('#image').val(image_url);
            jQuery('.imgContainer').html('<img src="'+image_url+'" width="100" />');
        });
    });

    jQuery('#upload-gallery-btn').click(function(e) {
        e.preventDefault();
        var image = wp.media({ 
            title: 'Upload Image',
            // mutiple: true if you want to upload multiple files at once
            multiple: true,
            library : {
                    type : 'image',
                }
        }).open()
        .on('select', function(e){
        	jQuery(".imgContainerGallery").html('');
            // This will return the selected image from the Media Uploader, the result is an object
            //console.log(image.state());
            //var uploaded_image = image.state().get('selection').first();
            // We convert uploaded_image to a JSON object to make accessing it easier
            // Output to the console uploaded_image
            //console.log(uploaded_image);
            //console.log(uploaded_image.toJSON().url);
            //var image_url = uploaded_image.toJSON().url;
            // Let's assign the url value to the input field
            //$('#image').val(image_url);
            //$('.imgContainer').html('<img src="'+image_url+'" width="100" />');
            var img_url = "";
            var selection = image.state().get('selection');
		      selection.map( function( attachment ) {
		        attachment = attachment.toJSON();
		        jQuery(".imgContainerGallery").append("<img src=" +attachment.url+" width=\"100\">");
		        img_url+=attachment.url+',';
        	});
		    img_url = img_url.substring(0, img_url.length - 1); 
		    jQuery('#image_gallery').val(img_url)
		    //alert(img_url);
		});
    });

});
function removeGalleryImage(imageUrl , floorplanid ,divClass)
{
	if(confirm('Are you sure to delete this image from gallery?')){
		//alert(imageUrl);
		jQuery.ajax({
			url:ajaxurl,
			data:'imageUrl='+imageUrl+'&floorplanid='+floorplanid+'&action=rrac_floorplan_gallery_image_delete',
			type:'POST',
			cache:false,
			success:function(data){
				console.log(data);
				if(data == 1)
				{
					alert('Image deleted successfully');
					jQuery('.'+divClass).remove();
				}						
			}
		});
	}
	
}

jQuery(document).ready( function () {
	var vertualTourSection = jQuery('input[name=vertual_tour]:checked').val();
	if(vertualTourSection == 1)
	{
		jQuery('#vertual_tour_section').show();
	}
	else
	{
		jQuery('#vertual_tour_section').hide();
	}

	jQuery('input[name=vertual_tour]').on('change',function(){
		if(jQuery(this).val() == 1)
		{
			jQuery('#vertual_tour_section').show();
		}
		else
		{
			jQuery('#vertual_tour_section').hide();
		}
	});


    $("#append").click( function(e) {
      e.preventDefault();
    $(".inc").append('<div class="row">\
            <div class="col-md-9"><textarea placeholder="Enter iframe code" class="form-control" name="vertual_tour_iframe[]"></textarea></div>\
            <div class="col-md-3"><a href="#" class="remove_this btn btn-danger">remove</a></div>\
            <div class="col-md-12">&nbsp;</div>\
        </div>');
    return false;
    });

    jQuery(document).on('click', '.remove_this', function() {
        jQuery(this).parent().parent().remove();
        return false;
        });
    
});
</script>

