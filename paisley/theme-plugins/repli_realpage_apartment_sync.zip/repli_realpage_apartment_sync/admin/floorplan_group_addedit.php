<?php
global $wpdb;
$page_title = 'Group Add';

if(isset($_GET['id']) && $_GET['id'] != "")
{
	$page_title = 'Group Edit';
	$table_name = $wpdb->prefix . 'rrac_floorplan_group';
	$sql_search = "select * from $table_name where id=".$_GET['id'];
	$search_res = $wpdb->get_row($sql_search);
}
// This will enqueue the Media Uploader script
wp_enqueue_media();
?>
<div class="col-md-12 rrac_app_edit_page rrac_admin_page">
	<h3><?php echo RRAC_PLUGIN_NAME;?> - <?php echo $page_title;?></h3>
	<hr/>
	<div class="alert alert-success" style="display: none;">
  		<button type="button" class="close">x</button>
	  	<strong>Success!</strong> Credential saved successfully.
	</div>
	<div class="col-md-12">
		<h4><?php echo $page_title;?>:</h4>
		<div class="col-md-12">&nbsp;</div>
		<form action="javascript:;" name="rrac_group_addedit" id="rrac_group_addedit" method="post" enctype="multipart/form-data">
			<input type="hidden" name="idd" value="<?php echo isset($search_res->id)?$search_res->id:''; ?>">
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Group Name:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="group_name" required="" value="<?php echo isset($search_res->group_name)?$search_res->group_name:''; ?>" ></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Bedroom:</label></div>
					<div class="col-md-9"><input type="number" class="form-control" name="bedroom" required="" value="<?php echo isset($search_res->bedroom)?$search_res->bedroom:''; ?>" ></div>
				</div>
			</div>
						
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Description:</label></div>
					<div class="col-md-9"><?php
					$args = array(
							    
							    'media_buttons' => true,
							    'wpautop' => false,
							    'tinymce' => array(
								        'theme_advanced_buttons1' => 'formatselect,|,bold,italic,underline,|,' .
								            'bullist,blockquote,|,justifyleft,justifycenter' .
								            ',justifyright,justifyfull,|,link,unlink,|' .
								            ',spellchecker,wp_fullscreen,wp_adv,fontsize'
								    )
							);
					 wp_editor( isset($search_res->description)?$search_res->description:'', 'description' , $args );
					 ?></div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Status:</label></div>
					<div class="col-md-9">
						<input type="radio" name="status" value="1" <?php if( isset($search_res->status) && $search_res->status == 1)echo "checked"?> required> Active
						<input type="radio" name="status" value="0" <?php if( isset($search_res->status) && $search_res->status == 0)echo "checked"?> required> Inactive
					</div>
				</div>
			</div>
			
			
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-12  text-center"><input id="submit" type="submit" class="btn btn-primary" name="Save" value="SAVE"></div>
				</div>
			</div>
		</form>
		
	</div>
</div>
<?php global $ajax_url;?>
<script>
	var ajaxurl = '<?php echo $ajax_url;?>';
	jQuery(document).ready(function(){
		jQuery('#rrac_group_addedit').on('submit', function(){
			var rrac_formdata = jQuery('#rrac_group_addedit').serialize();
			jQuery.ajax({
				url:ajaxurl,
				data:rrac_formdata+'&action=rrac_group_addedit',
				type:'POST',
				cache:false,
				success:function(data){
					console.log(data);
					if(data == 1)
					{
						alert('Data updated successfully.');
						window.location.href="<?php echo admin_url('admin.php?page=rrac_floorplan_group'); ?>";
						
					}						
				}
			})
			return false;
		});
		jQuery('.alert-success .close').on('click',function(){
	        jQuery(this).closest('.alert').slideUp();
	   });
		jQuery('#submit').mousedown( function() {
		    tinyMCE.triggerSave();
		});
	});
	
		
</script>

