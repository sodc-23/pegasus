<div class="col-md-12 rrac_config_page rrac_admin_page">
	<h3><?php echo RRAC_PLUGIN_NAME;?> - Configuration</h3>
	<hr/>
	<div class="alert alert-success" style="display: none;">
  		<button type="button" class="close">x</button>
	  	<strong>Success!</strong> Credential saved successfully.
	</div>


	<ul class="nav nav-tabs">
	  <li class="active"><a data-toggle="tab" href="#Realpage_API_Credential">Realpage API Credential</a></li>
	  <li><a data-toggle="tab" href="#Color_Settings">Color/style Settings</a></li>
	  <li><a data-toggle="tab" href="#API_Data_Settings">API Data Settings</a></li>
	  <li><a data-toggle="tab" href="#API_User_Guide">API User Guide</a></li>
	</ul>

	
	<form action="javascript:;" name="rrac_config_frm" id="rrac_config_frm" method="post">

	<div class="tab-content">
		<div class="col-md-12">&nbsp;</div>
		<!--------------------------------Start API Config------------------------------------>
		<div id="Realpage_API_Credential" class="tab-pane fade in active">
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>API Username:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="realpage_api_user"  value="<?php echo get_option('realpage_api_user'); ?>"></div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>API Password:</label></div>
					<div class="col-md-9"><input type="password" class="form-control" name="realpage_api_password"  value="<?php echo get_option('realpage_api_password'); ?>"></div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>API SiteID:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="realpage_api_siteid"  value="<?php echo get_option('realpage_api_siteid'); ?>"></div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>API PmcID:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="realpage_api_pmcid"  value="<?php echo get_option('realpage_api_pmcid'); ?>"></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-12  text-center"><input type="submit" class="btn btn-primary" name="Save" value="SAVE"></div>
				</div>
			</div>

		</div>
		<!--------------------------------End API Config------------------------------------>

		<!--------------------------------Start color scheme------------------------------------>
		<div id="Color_Settings" class="tab-pane fade">

			<div class="defaultColorBtn">
				<a href="javascript:;" onclick="setDefaultColors('list_view_1');" class="float-right" style="float: left;">Plugin Default(List View 1)</a>
				<a href="javascript:;" onclick="setDefaultColors('list_view_2');" class="float-right" style="float: right;">Plugin Default(List View 2)</a></div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Default Color(Text):</label></div>
					<div class="col-md-9"><input type="color" class="form-control1" name="rrac_default_color_text"  value="<?php echo get_option('rrac_default_color_text'); ?>"></div>
				</div>
			</div>

			<div class="">&nbsp;</div>
			<h4>Tab Header:</h4>
			<div>
				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Tab Area Background:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_tab_area_background"  value="<?php echo get_option('rrac_tab_area_background'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Tab Heading Background:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_tab_heading_background"  value="<?php echo get_option('rrac_tab_heading_background'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Tab Heading Text:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_tab_heading_text"  value="<?php echo get_option('rrac_tab_heading_text'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Tab Heading Background(Active):</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_tab_heading_background_active"  value="<?php echo get_option('rrac_tab_heading_background_active'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Tab Heading Text(Active):</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_tab_heading_text_active"  value="<?php echo get_option('rrac_tab_heading_text_active'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Tab Heading Border Radius:</label></div>
						<div class="col-md-9"><input type="number" min="0" class="form-control1" name="rrac_tab_heading_border_radius"  value="<?php echo get_option('rrac_tab_heading_border_radius'); ?>">PX</div>
					</div>
				</div>
				

			</div>
			<div class="">&nbsp;</div>
			<h4>Tab Content:</h4>
			<div>
				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Tab Content Background:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_tab_content_background"  value="<?php echo get_option('rrac_tab_content_background'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Tab Content Border Bottom:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_tab_content_border_bottom"  value="<?php echo get_option('rrac_tab_content_border_bottom'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Apartment Title:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_appartment_title"  value="<?php echo get_option('rrac_appartment_title'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Apartment Tagline:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_appartment_tagline"  value="<?php echo get_option('rrac_appartment_tagline'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Apartment highlighted Text:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_appartment_highlighted_text"  value="<?php echo get_option('rrac_appartment_highlighted_text'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Button Background:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_button_background"  value="<?php echo get_option('rrac_button_background'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Button Border:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_button_border"  value="<?php echo get_option('rrac_button_border'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Button Text:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_button_text"  value="<?php echo get_option('rrac_button_text'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Button Background(Hover):</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_button_background_hover"  value="<?php echo get_option('rrac_button_background_hover'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Button Text(Hover):</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_button_text_hover"  value="<?php echo get_option('rrac_button_text_hover'); ?>"></div>
					</div>
				</div>


				<!----------------------------->
				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Secondary Button Background:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_secondary_button_background"  value="<?php echo get_option('rrac_secondary_button_background'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Secondary Button Border:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_secondary_button_border"  value="<?php echo get_option('rrac_secondary_button_border'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Secondary Button Text:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_secondary_button_text"  value="<?php echo get_option('rrac_secondary_button_text'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Secondary Button Background(Hover):</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_secondary_button_background_hover"  value="<?php echo get_option('rrac_secondary_button_background_hover'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Secondary Button Text(Hover):</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_secondary_button_text_hover"  value="<?php echo get_option('rrac_secondary_button_text_hover'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>ALL Button Border Radius:</label></div>
						<div class="col-md-9"><input type="number" min="0" class="form-control1" name="rrac_btn_border_radius"  value="<?php echo get_option('rrac_btn_border_radius'); ?>">PX</div>
					</div>
				</div>

			</div>

			<div class="">&nbsp;</div>
			<h4>Modal Area:</h4>
			<div>
				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Modal Content Heading:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_modal_content_heading"  value="<?php echo get_option('rrac_modal_content_heading'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Modal Table Border:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_modal_table_border"  value="<?php echo get_option('rrac_modal_table_border'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Modal Datepicker Active Date:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_modal_datepickert_active"  value="<?php echo get_option('rrac_modal_datepickert_active'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Modal Datepicker Active Date(Background):</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_modal_datepickert_active_background"  value="<?php echo get_option('rrac_modal_datepickert_active_background'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Modal Lease Now Button:</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_modal_lease_now_button"  value="<?php echo get_option('rrac_modal_lease_now_button'); ?>"></div>
					</div>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-md-3"><label>Modal Lease Now Button(Background):</label></div>
						<div class="col-md-9"><input type="color" class="form-control1" name="rrac_modal_lease_now_button_background"  value="<?php echo get_option('rrac_modal_lease_now_button_background'); ?>"></div>
					</div>
				</div>

				

			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Put Your Own CSS:</label></div>
					<div class="col-md-9"><textarea class="form-control" rows="10" name="rrac_own_css"><?php echo get_option('rrac_own_css'); ?></textarea></div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-12  text-center"><input type="submit" class="btn btn-primary" name="Save" value="SAVE"></div>
				</div>
			</div>

		</div>
		<!--------------------------------End color scheme-------------------------------------->

		<div id="API_Data_Settings" class="tab-pane fade">
			

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Site Available Page URL:</label></div>
					<div class="col-md-9"><input type="url" class="form-control" name="site_available_page_url"  value="<?php echo get_option('site_available_page_url'); ?>"></div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Result Show how many days next from move in date?:</label></div>
					<div class="col-md-9"><input type="number" class="form-control" name="result_show_next_days"  value="<?php echo get_option('result_show_next_days'); ?>"></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Result Show how many days previous from move in date?:</label></div>
					<div class="col-md-9"><input type="number" class="form-control" name="result_show_prev_days"  value="<?php echo get_option('result_show_prev_days'); ?>"></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>How many upcoming days show on Calendar?:</label></div>
					<div class="col-md-9"><input type="number" class="form-control" name="calendar_upcoming_days"  value="<?php echo get_option('calendar_upcoming_days'); ?>"></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Schedule tour button Action type:</label></div>
					<div class="col-md-9">
						<select name="schedule_tour_action_type" class="form-control">
							<option value="">Select</option>
							<option value="html" <?php echo get_option('schedule_tour_action_type')=='html'?'selected':''; ?>>HTML</option>
							<option value="javascript" <?php echo get_option('schedule_tour_action_type')=='javascript'?'selected':''; ?>>Javascript Function</option>
						</select>
						
					</div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Enter Schedule tour button URL/Javascript function?:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="schedule_tour_action"  value="<?php echo get_option('schedule_tour_action'); ?>"></div>
				</div>
			</div>

			<!---------------------------contact button-------------------------------->
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Contact Button Action type:</label></div>
					<div class="col-md-9">
						<select name="contact_action_type" class="form-control">
							<option value="">Select</option>
							<option value="html" <?php echo get_option('contact_action_type')=='html'?'selected':''; ?>>HTML</option>
							<option value="javascript" <?php echo get_option('contact_action_type')=='javascript'?'selected':''; ?>>Javascript Function</option>
						</select>
						
					</div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Enter Contact button URL/Javascript function?:</label></div>
					<div class="col-md-9"><input type="text" class="form-control" name="contact_action"  value="<?php echo get_option('contact_action'); ?>"></div>
				</div>
			</div>
			<!---------------------------contact button-------------------------------->
			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Email Send To:</label></div>
					<div class="col-md-9"><input type="email" class="form-control" name="rrac_contact_email"  value="<?php echo get_option('rrac_contact_email'); ?>"></div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-3"><label>Display Maximum Available Unit:</label></div>
					<div class="col-md-9">
						<select name="rrac_display_max_available_unit" class="form-control" >
							<option value="">Default</option>
							<?php 
							for($j=1; $j<=20; $j++){
								?>
								<option value="<?php echo $j;?>" <?php if(get_option('rrac_display_max_available_unit') == $j) echo "selected";  ?> ><?php echo $j;?></option>
								<?php
							} 
							?>
						</select>
						
					</div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-md-12  text-center"><input type="submit" class="btn btn-primary" name="Save" value="SAVE"></div>
				</div>
			</div>
		</div>

		<!--------------------------------End color scheme-------------------------------------->

		<div id="API_User_Guide" class="tab-pane fade">
			
			<div class="col-md-6">
				<h3>List View 1</h3>
				<div class="imgpreview"><img src="<?php echo plugins_url('/repli_realpage_apartment_sync/assets/images/highlandView.png') ?>" alt="List View 1" width="90%" /></div>
				<div class="shortCodeText"><b>[apartment_type_tab_view type="list_view_1"]</b></div>
			</div>
			<div class="col-md-6">
				<h3>List View 2</h3>
				<div class="imgpreview"><img src="<?php echo plugins_url('/repli_realpage_apartment_sync/assets/images/sentosaView.png') ?>" alt="List View 2" width="90%" /></div>
				<div class="shortCodeText"><b>[apartment_type_tab_view type="list_view_2"]</b></div>
			</div>

			<div class="col-md-12">&nbsp;</div>
			<div class="col-md-12">&nbsp;</div>
			<h3>Starting Price Shortcode:</h3>

			<div class="col-md-12">
				<div class="col-md-6">Get Starting price From All Unit Use Shortcode:</div>
				<div class="col-md-6"><b>[rrac_min_unit_price]</b></div>
			</div>
			<div class="col-md-12">&nbsp;</div>
			<div class="col-md-12">
				<div class="col-md-6">Get Starting price By Bedroom Wise:</div>
				<div class="col-md-6"><b>[rrac_min_unit_price bedroom="X"]</b> <br>
					<span>X=> 1,2,3</span>
				</div>
			</div>
			<div class="col-md-12">&nbsp;</div>
			<div class="col-md-12">
				<div class="col-md-6">Get Starting price By Floor Plan Wise:</div>
				<div class="col-md-6"><b>[rrac_min_unit_price floorplan_id="X"]</b> <br>
					<span>X=> 1,2,3 ( if you also give bedroom parameter then output result will ignore floorplan_id because bedroom priority high in our programe. )</span>
				</div>
			</div>

			<div class="col-md-12">&nbsp;</div>
			<div class="col-md-12">&nbsp;</div>
			<h3>Cron setup Tips:</h3>
			<div class="col-md-12">
				Please setup cron to get plugin update available notification. 
				<br>
				Put the following URL in cron setup:
				<br>
				<b><?php echo get_bloginfo('home').'/wp-content/plugins/repli_realpage_apartment_sync/update_check_cron.php' ?></b>
			</div>

			<div class="col-md-12">
				Please setup cron to get latest available unit details . 
				<br>
				Put the following URL in cron setup:
				<br>
				<b><?php echo get_bloginfo('home').'/wp-content/plugins/repli_realpage_apartment_sync/first_load_cron.php' ?></b>
			</div>

			
		</div>

	</div>
	</form>
	
</div>
<?php global $ajax_url;?>
<script >
	var ajaxurl = '<?php echo $ajax_url;?>';
	jQuery(document).ready(function(){
		jQuery('#rrac_config_frm').on('submit', function(){
			var rrac_formdata = jQuery('#rrac_config_frm').serialize();
			jQuery.ajax({
				url:ajaxurl,
				data:rrac_formdata+'&action=rrac_configuration_add',
				type:'POST',
				cache:false,
				success:function(data){
					if(data == 1)
					{
						jQuery(".alert-success").fadeIn();
						setTimeout(function(){jQuery(".alert-success").fadeOut(1000);},5000);
						jQuery('html, body').animate({
					        scrollTop: jQuery(".alert-success").offset().top -50
					    }, 500);
						
					}
					
				}
			})
			return false;
		});

		jQuery('.alert-success .close').on('click',function(){
	        jQuery(this).closest('.alert').slideUp();
	   });

	   jQuery('input[type=color]').each(function(){
	        jQuery(this).parent().append(' OR <input type="text" class="color_hex" id="'+jQuery(this).attr('name')+'_hex" pattern="#+([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$" value="'+jQuery(this).attr('value')+'" onchange="hexChange(this.id);" >');
	   });

	   jQuery('input[type=color]').on('change',function(){
	   		var hexId = jQuery(this).attr('name');
	   		//alert(hexId);
	   		jQuery('#'+hexId+'_hex').val(jQuery(this).val());
	   });


	});
	function hexChange(id)
	{
		var fieldName = id.slice(0,-4);
		var data = jQuery('#'+id).val();
		if(data.match(/#[0-9a-f]{6}/ig) )
		{
			jQuery('#'+id).css('background','none');
			jQuery('input[name='+fieldName+']').val(data);
		}
		else
		{
			jQuery('#'+id).css('background','red');
		}
	}


	function setDefaultColors(template)
	{
		if(confirm('Are you sure to get default values? If yes then it will overwrite all colors.'))
		{
			jQuery.ajax({
				url:ajaxurl,
				data:'action=rrac_setDefaultColors&template='+template,
				type:'POST',
				cache:false,
				success:function(data){
					if(data == 1)
					{
						window.location.reload(true);
						
					}
					
				}
			})
		}
	}

	


		
</script>

