<div class="col-md-12 rrac_app_tab_heading_page rrac_admin_page">
	<?php
	global $wpdb;
	   $table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
	   $sql_search_by_grp = "select *,substr(floorplan_code,1,1) as code from $table_name where status=1 group by code order by order_no asc";
	   $search_res_by_grps = $wpdb->get_results($sql_search_by_grp);
	   $rrac_tab_heading = get_option('rrac_tab_heading');
	   $appTypeArray = array();
	   if($rrac_tab_heading != "")
	   {
	   		$appTypeArray = json_decode($rrac_tab_heading,true);
	   }

	?>
	<h3><?php echo RRAC_PLUGIN_NAME;?> - Tab Heading</h3>
	<hr/>
	

	<div class="col-md-12">
		<h4>Tab Heading Edit:</h4>
		<form action="javascript:;" name="headingSave" id="headingSave" method="POST"> 
			
	  		<ul>
			<?php
			$count = 0; 
			foreach($search_res_by_grps as $search_res_by_grp)
	        {
	            if(isset($appTypeArray[$search_res_by_grp->code])) 
	              $appTypeName = $appTypeArray[$search_res_by_grp->code];
	            else
	              $appTypeName = $search_res_by_grp->code;
	          ?>
	            <li>Code Type Start With "<?php echo $search_res_by_grp->code;?>" Means <span><input type="text" name="<?php echo $search_res_by_grp->code;?>" value="<?php echo $appTypeName;?>" size="100" required></span></li>
	          <?php
	          $count++;
	        }
	        
	        ?>
	        <li class="saveBtn" style="text-align: center;"><input type="submit" name="submit" value="Save"></li>
			</ul>
		</form>
		<?php
		if($count == 0)
		{
			echo "No data available.";
		}
		?>
	</div>
</div>
<?php global $ajax_url;?>

  
<script >
	var ajaxurl = '<?php echo $ajax_url;?>';
	jQuery(document).ready(function(){
		
		jQuery('#headingSave').submit(function(){
			jQuery('.rrac_admin_overlay').show();
			var datas = jQuery('#headingSave').serialize();
			
			jQuery.ajax({
				url:ajaxurl,
				data:datas+'&action=rrac_tab_heading_save',
				type:'POST',
				cache:false,
				success:function(data){
					console.log(data);
					if(data == 1)
					{
						alert('Updated successfully');
						jQuery('.rrac_admin_overlay').hide();
					}						
				}
			});
		});
		jQuery('.rrac_admin_page').css('min-height',jQuery(document).height()+'px');
	});


		
</script>
<div class="rrac_admin_overlay" >
	<div class="content_area">Processing.....</div>
</div>
