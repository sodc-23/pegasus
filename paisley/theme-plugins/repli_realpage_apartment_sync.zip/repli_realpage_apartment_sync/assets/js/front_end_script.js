//alert(ajaxurl);

var desiredMoveinDate = phpVar['default_move_in_date'];
var ajaxurl = phpVar['ajax_url'];
var plugin_url = phpVar['plugin_url'];
var currentUnitId = "";
var RRAC_SITE_AVAILABLE_PAGE = phpVar['RRAC_SITE_AVAILABLE_PAGE'];
var CALENDAR_UPCOMING_DAYS = phpVar['CALENDAR_UPCOMING_DAYS'];
var current_floorplan_id = '';

function rrac_show_aprt_det(id)
{
	
	//jQuery('.rrac_loader_container').show();
	jQuery('#rrac_apartment_details').modal('show');
	jQuery('#rrac_apartment_details .appIntScreen').css('left',0);
	jQuery('#rrac_apartment_details .appDetScreen').css('left','120%');
	jQuery('#rrac_apartment_details .appUnitListScreen').css('left','120%');
	jQuery('#rrac_apartment_details .appContactFormScreen').css('left','120%');
	jQuery('#rrac_apartment_details .appContactFormScreen').html('');
	//return false;
	jQuery.ajax({
				url:ajaxurl,
				data:'apartment_id='+id+'&action=rrac_show_aprt_det',
				type:'POST',
				cache:false,
				success:function(data){
					console.log(data);
					jQuery('#rrac_apartment_details').scrollTop(0);
					var res = jQuery.parseJSON(data);
					//jQuery('#rrac_apartment_details .modal-body').html(res.str);
					//jQuery('#rrac_apartment_details .modal-title').html(res.name);
					//appDetScreen  appUnitListScreen
					jQuery('#rrac_apartment_details .appDetScreen').html(res.str);
					//jQuery('#rrac_apartment_details .modal-title').html(res.name);
					setTimeout(function(){
						jQuery('#rrac_apartment_details .appIntScreen').animate({'left':'-100%'},800);
						jQuery('#rrac_apartment_details .appDetScreen').animate({'left':'0'},800);
					},500);
					
					//jQuery('#rrac_apartment_details').modal('show');
					//setTimeout(function(){jQuery('.rrac_loader_container').hide();},600);
				}
			});
}

function getUnitListByFloor(floorPlanID , template_type)
{
	var template_type = template_type || 1;
	current_floorplan_id = floorPlanID; ////set apartment id on global variable
	if(template_type == 2)
	{
		jQuery('.rrac_loader_container').show();
	}
	jQuery('.appDetScreen .detLoad').show();
	jQuery('#rrac_apartment_details .appIntScreen').css('left','-120%');
	jQuery('#rrac_apartment_details .appDetScreen').css('left','0');
	jQuery('#rrac_apartment_details .appUnitListScreen').css('left','120%');
	jQuery('#rrac_apartment_details .appContactFormScreen').css('left','120%');
	jQuery.ajax({
				url:ajaxurl,
				data:'floorPlanID='+floorPlanID+'&moveinDate='+desiredMoveinDate+'&action=rrac_getUnitListByFloor',
				type:'POST',
				cache:false,
				success:function(data){
					console.log(data);
					var res = jQuery.parseJSON(data);

					//jQuery('#rrac_apartment_unit_list .modal-body').html(res.str);
					//jQuery('#rrac_apartment_unit_list .modal-title').html(res.name);
					//jQuery('#rrac_apartment_unit_list').modal('show');
					//setTimeout(function(){jQuery('.rrac_loader_container').hide();},600);

					jQuery('.appDetScreen .detLoad').hide();
					var backBtn = '<a class="backem" href="javascript:;" onclick="backToDet();"><i class="fa fa-arrow-left"></i> Back</a>';
					jQuery('#rrac_apartment_details .appUnitListScreen').html(backBtn + res.str);
					//jQuery('#rrac_apartment_details .modal-title').html(res.name);
					setTimeout(function(){
						jQuery('#rrac_apartment_details .appDetScreen').animate({'left':'-100%'},800);
						jQuery('#rrac_apartment_details .appUnitListScreen').animate({'left':'0'},800);
					},200);
					setTimeout(function(){	jQuery('#rrac_apartment_details .modal-content').scrollTop(0); 
											jQuery('#rrac_apartment_details').modal('show');
											jQuery('.rrac_loader_container').hide();
										},1000);

					
					jQuery('#move_in_date').datepicker({
						dateFormat: 'dd MM yy',
						minDate: 0,
						maxDate: CALENDAR_UPCOMING_DAYS,
						beforeShow: function(input, inst) {
					       //jQuery('#ui-datepicker-div').removeClass(inputIds);
					       jQuery('#ui-datepicker-div').addClass(this.id);
					   },
						onSelect: function(dateText, inst) {
									  desiredMoveinDate = dateText;
								      console.log(inst);
								      getUnitListByFloorDateChange(floorPlanID);
								   }
					});
				}
			});
}
function getUnitListByFloorDateChange(floorPlanID)
{
	//jQuery('.rrac_loader_container').show();
	jQuery('#rrac_apartment_details .appUnitListScreen .desiredEmptyMessage').html('<img src="'+plugin_url+'/assets/images/loading.svg" width="70" alt="" />');
	jQuery('.rrac_listAvailableUnit').html('');
	jQuery.ajax({
				url:ajaxurl,
				data:'floorPlanID='+floorPlanID+'&moveinDate='+desiredMoveinDate+'&action=rrac_getUnitListByFloor',
				type:'POST',
				cache:false,
				success:function(data){
					console.log(data);
					var res = jQuery.parseJSON(data);
					
					//jQuery('.rrac_loader_container').hide();
					var backBtn = '<a class="backem" href="javascript:;" onclick="backToDet();"><i class="fa fa-arrow-left"></i> Back</a>';
					jQuery('#rrac_apartment_details .appUnitListScreen').html(backBtn + res.str);
					//jQuery('#rrac_apartment_details .modal-title').html(res.name);
					setTimeout(function(){jQuery('#rrac_apartment_details .modal-content').scrollTop(0);},100);
					jQuery('#move_in_date').datepicker({
						dateFormat: 'dd MM yy',
						minDate: 0,
						maxDate: CALENDAR_UPCOMING_DAYS,
						beforeShow: function(input, inst) {
					       //jQuery('#ui-datepicker-div').removeClass(inputIds);
					       jQuery('#ui-datepicker-div').addClass(this.id);
					   },
						onSelect: function(dateText, inst) {
									  desiredMoveinDate = dateText;
								      console.log(inst);
								      getUnitListByFloorDateChange(floorPlanID);
								   }
					});
				}
			});
}
function backToDet()
{

	jQuery('#rrac_apartment_details .appDetScreen').animate({'left':'0'},800);
	jQuery('#rrac_apartment_details .appUnitListScreen').animate({'left':'120%'},800);
	setTimeout(function(){jQuery('#rrac_apartment_details .modal-content').scrollTop(0);},800);
}
function getContactFormSlide(direct_open , floorplan_id)
{
	var direct_open = direct_open || "";
	var floorplan_id = floorplan_id || "";
	if(direct_open == 'direct_open')
	{
		jQuery('.rrac_loader_container').show();
		current_floorplan_id = floorplan_id;
	}

	jQuery.ajax({
		url:ajaxurl,
		data:'action=rrac_getContactForm',
		type:'POST',
		cache:false,
		success:function(data){
			var backBtn = '<a class="backem" href="javascript:;" onclick="backToUnitList();"><i class="fa fa-arrow-left"></i> Back</a>';
			jQuery('#rrac_apartment_details').find('.appDetScreen').html('');
			if(direct_open == 'direct_open')
			{
				jQuery('#rrac_apartment_details .appContactFormScreen').html(data);
			}
			else
			{
				jQuery('#rrac_apartment_details .appContactFormScreen').html(backBtn + data);
			}

			jQuery('#rrac_apartment_details .appUnitListScreen').animate({'left':'-100%'},800);
			jQuery('#rrac_apartment_details .appContactFormScreen').animate({'left':'0'},800);
			jQuery('#rrac_apartment_details .appIntScreen').css('left','-120%');
			setTimeout(function(){	
				jQuery('#rrac_apartment_details .modal-content').scrollTop(0); 
				jQuery('#rrac_apartment_details').modal('show');
				jQuery('.rrac_loader_container').hide();
			},1000);
		}
	});
	
}
function backToUnitList()
{
	jQuery('#rrac_apartment_details .appUnitListScreen').animate({'left':'0'},800);
	jQuery('#rrac_apartment_details .appContactFormScreen').animate({'left':'120%'},800);
	setTimeout(function(){jQuery('#rrac_apartment_details .modal-content').scrollTop(0);},800);
}
function rrac_contactFormSubmit()
{
	jQuery('.rrac_contactForm .detLoad').show();
	jQuery('#rrac_contactForm .btn').attr('disabled',true);
	var datas = jQuery('#rrac_contactForm').serialize();
	
	jQuery.ajax({
		url:ajaxurl,
		data:datas+'&current_floorplan_id='+current_floorplan_id+'&action=rrac_submitContactForm',
		type:'POST',
		cache:false,
		success:function(data){
			jQuery('.rrac_contactForm .detLoad').hide();
			if(data == 1)
			{
				var mesg = '<h3 class="mailSuccessMsg">Your request sent successfully. We will contact you soon.</h3>';
				jQuery('#rrac_apartment_details .appContactFormScreen .ContactFormArea').html(mesg);
			}
			else
			{
				alert('Message not send. Try again');
				jQuery('#rrac_contactForm .btn').attr('disabled',false);
			}
			
		}
	});
}
function goto_lease(unitId , availableDate)
{
	var desMovInDate = formatDate(desiredMoveinDate);
	var availableDateFormatted = formatDate(availableDate);
	var maxDate = new Date(availableDateFormatted);
	var maxDate = new Date(availableDateFormatted);

	maxDate.setTime(maxDate.getTime() + 30 * 24 * 60 * 60 * 1000); 
	var thirtyDaysFrommaxDate = formatDate(maxDate);
	//alert(availableDateFormatted);
	//alert(desMovInDate);
	if(desMovInDate >= availableDateFormatted)
	{
		window.open(RRAC_SITE_AVAILABLE_PAGE+'?UnitId='+unitId+'&MoveInDate='+desMovInDate , '_self');  
	}
	else
	{
		currentUnitId = unitId;
		jQuery("#leaseMoveInDate").datepicker("destroy");
		jQuery('#leaseMoveInDate').datepicker({
			dateFormat: 'yy-mm-dd',
			minDate : availableDateFormatted,
			maxDate : thirtyDaysFrommaxDate
		});
		jQuery('#leaseMoveInDate').datepicker('setDate', availableDateFormatted);

		jQuery('#rrac_datepickerView').modal('show');
	}
}
function gotoLeaseAfterDateChange()
{
	var leaseDate = formatDate_lease(jQuery("#leaseMoveInDate").datepicker( 'getDate' ) );
	if(currentUnitId != '' && leaseDate != '')
	{
		window.open(RRAC_SITE_AVAILABLE_PAGE+'?UnitId='+currentUnitId+'&MoveInDate='+leaseDate , '_self'); 
		jQuery('#rrac_datepickerView').modal('hide');
	}
	else
	{
		alert('Some error. Try again.');
	}
}
function formatDate(date) {
     var d = new Date(date),
         month = '' + (d.getMonth() + 1),
         day = '' + d.getDate(),
         year = d.getFullYear();

     if (month.length < 2) month = '0' + month;
     if (day.length < 2) day = '0' + day;

     return [year, month, day].join('-');
 }
 
 function formatDate_lease(date) {
     var d = new Date(date),
         month = '' + (d.getMonth() + 1),
         day = '' + d.getDate(),
         year = d.getFullYear();

     if (month.length < 2) month = '0' + month;
     if (day.length < 2) day = '0' + day;

     return [month, day, year].join('/');
 }


jQuery(document).ready(function(){
	var append_string = '';
	append_string+='<div class="rrac_modal_container">';
	//////loading screen/////
	append_string+='<div class="rrac_loader_container"><div class="img_section"><img src="'+plugin_url+'/assets/images/loading.svg" width="" alt="" /></div></div>';
	
	//////loading screen End/////
	//////FloorPlan Details
	append_string+='<div id="rrac_apartment_details" class="modal fade" role="dialog">';
	  append_string+='<div class="modal-dialog">';

	    
	    append_string+='<div class="modal-content">';
	    append_string+='<div class="modal-header">';
	    append_string+='<button type="button" class="close pop-up-close" data-dismiss="modal">&times;</button>';
	    append_string+='</div>';
	    append_string+='<div class="modal-body">';
	    append_string+='<div class="slideScreen appIntScreen"><div class="img_section"><img src="'+plugin_url+'/assets/images/loading.svg" width="100" alt="" /></div></div>';
	    append_string+='<div style="left: 120%;" class="slideScreen appDetScreen"></div>';
	    append_string+='<div style="left: 120%;" class="slideScreen appUnitListScreen"></div>';
	    append_string+='<div style="left: 120%;" class="slideScreen appContactFormScreen"></div>';
	    append_string+='</div>';
	    append_string+='</div>';

	  append_string+='</div>';
	append_string+='</div>';


	//////Unit List By FloorPlan
	append_string+='<div id="rrac_apartment_unit_list" class="modal fade" role="dialog">';
	  append_string+='<div class="modal-dialog">';

	    
	    append_string+='<div class="modal-content">';
	    append_string+='<div class="modal-header">';
	    append_string+='<button type="button" class="close" data-dismiss="modal">&times;</button>';
	    append_string+='<h4 class="modal-title">Modal Header</h4>';
	    append_string+='</div>';
	    append_string+='<div class="modal-body">';
	    append_string+='<p>Some text in the modal.</p>';
	    append_string+='</div>';
	    append_string+='</div>';

	  append_string+='</div>';
	append_string+='</div>';


	//////Date Picker Modal
	append_string+='<div id="rrac_datepickerView" class="modal fade" role="dialog">';
	  append_string+='<div class="modal-dialog">';

	    
	    append_string+='<div class="modal-content">';
	    append_string+='<div class="modal-header">';
	    append_string+='<button type="button" class="close" data-dismiss="modal">&times;</button>';
	    append_string+='<h4 class="modal-title">Select Desired Move In Date</h4>';
	    append_string+='</div>';
	    append_string+='<div class="modal-body">';
	    append_string+='<div id="leaseMoveInDate"></div>';
	    append_string+='<div class="leaseNowButton"><a href="javascript:;" onclick="gotoLeaseAfterDateChange();" >Lease Now <i class="fa fa-angle-right" aria-hidden="true"></i></a></div>';
	    append_string+='</div>';
	    append_string+='</div>';

	  append_string+='</div>';
	append_string+='</div>';

	//////Floorplan Gallery Modal
	append_string+='<div id="rrac_Floorplan_Gallery" class="modal fade" role="dialog">';
	  append_string+='<div class="modal-dialog">';

	    
	    append_string+='<div class="modal-content">';
	    append_string+='<div class="modal-header">';
	    append_string+='<button type="button" class="close" data-dismiss="modal">&times;</button>';
	    append_string+='<h4 class="modal-title"></h4>';
	    append_string+='</div>';
	    append_string+='<div class="modal-body">';
	    append_string+='';
	    append_string+='';
	    append_string+='</div>';
	    append_string+='</div>';

	  append_string+='</div>';
	append_string+='</div>';


	
	append_string+='</div">';

	jQuery('body').prepend(append_string);

	jQuery('.rrac_modal_container .modal').on("hidden.bs.modal", function (e) { 

		//jQuery('.modal').find('.modal-dialog').find('.modal-body').html('');
	    if (jQuery('.modal:visible').length) { 
	        jQuery('body').addClass('modal-open');
	    }
	});

	jQuery("#rrac_Floorplan_Gallery").on("hide.bs.modal", function () {
	    jQuery('#rrac_Floorplan_Gallery .modal-body').html('');
	});

});

	// jQuery('#rrac_apartment_unit_list').on('hide.bs.modal', function (e) {
 //    	//e.preventDefault();
 //    	console.log('repliiiiiiiiii');
 //    	jQuery('#rrac_apartment_unit_list > .modal-body').html('');

	// });

jQuery(window).load(function(){

      jQuery('.rracShortcodeSectionMinUnitPrice').each(function(){
        //alert();
        	var bedroom = jQuery(this).data('bedroom');
        	var floorplan_id = jQuery(this).data('floorplanid');
        	var resultId = jQuery(this).data('id');
            jQuery.ajax({
              url:ajaxurl,
              data:"bedroom="+bedroom+"&floorplan_id="+floorplan_id+"&action=rrac_show_shortcode_min_unit_price_data",
              type:"POST",
              cache:false,
              success:function(data){
                //alert(data);
                jQuery('#'+resultId).html(data);
              }
          });
                
      });
  });

function show_floorplan_gallery(id)
{
	//alert(id);
	jQuery.ajax({
	      url:ajaxurl,
	      data:"id="+id+"&action=rrac_show_floorplan_gallery",
	      type:"POST",
	      cache:false,
	      success:function(data){
	        jQuery('#rrac_Floorplan_Gallery .modal-body').html(data);
	        jQuery('#rrac_Floorplan_Gallery').modal('show');
	      }
	  });
	
}