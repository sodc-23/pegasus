<?php 
//require_once('../../../../wp-load.php');
function my_dynamic_styles() { 
	$all_options_dynamik = wp_load_alloptions();
	?>
	<!--------------Start RRAC Plugin CSS------------------>
	<style type="text/css">
		
		.rrac_tabSection{background: <?php echo $all_options_dynamik['rrac_tab_area_background'] ?> !important;}
		.rrac_tabSection .nav.nav-tabs li{background: <?php echo $all_options_dynamik['rrac_tab_heading_background'] ?> !important;}
		.rrac_tabSection .nav.nav-tabs li a{color:<?php echo $all_options_dynamik['rrac_tab_heading_text'] ?> !important;}
		.rrac_tabSection .nav.nav-tabs li:first-child{border-radius:<?php echo $all_options_dynamik['rrac_tab_heading_border_radius'] ?>px 0 0 <?php echo $all_options_dynamik['rrac_tab_heading_border_radius'] ?>px;}
		.rrac_tabSection .nav.nav-tabs li:last-child{border-radius:0 <?php echo $all_options_dynamik['rrac_tab_heading_border_radius'] ?>px <?php echo $all_options_dynamik['rrac_tab_heading_border_radius'] ?>px 0;}

		.rrac_tabSection .nav.nav-tabs li.active a {background: <?php echo $all_options_dynamik['rrac_tab_heading_background_active'] ?> !important;}
		.rracSentosa .nav.nav-tabs li.active a:after{ color: <?php echo $all_options_dynamik['rrac_tab_heading_background_active'] ?> !important; }
		.rrac_tabSection .nav.nav-tabs li.active a  {color: <?php echo $all_options_dynamik['rrac_tab_heading_text_active'] ?> !important;}
		/******** tab content area **************/
		.rrac_tabSection .tab-content .rrac_appt_det, .rrac_modal_container .apt_description,.rrac_modal_container #rrac_apartment_unit_list label , .rrac_modal_container .apt_details_single_line{color:<?php echo $all_options_dynamik['rrac_default_color_text'] ?> !important;}
		.rrac_tabSection .tab-content .rrac_appt_det span{color:<?php echo $all_options_dynamik['rrac_appartment_highlighted_text'] ?> !important;}
		.rrac_tabSection .tab-content .tab-pane.fade.active.in .col-md-12{background: <?php echo $all_options_dynamik['rrac_tab_content_background'] ?> !important;border-bottom: 1px solid <?php echo $all_options_dynamik['rrac_tab_content_border_bottom'] ?> !important;}
		.rrac_tabSection .tab-content .appname{color:<?php echo $all_options_dynamik['rrac_appartment_title'] ?> !important;}
		.rrac_tabSection .tab-content .tagline , .rrac_modal_container .tagline{color: <?php echo $all_options_dynamik['rrac_appartment_tagline'] ?> !important;}
		.rrac_tabSection .tab-content .rrac_appt_btn a, .rrac_modal_container .apt_button a{background:<?php echo $all_options_dynamik['rrac_button_background'] ?> !important;color: <?php echo $all_options_dynamik['rrac_button_text'] ?> !important;border: 1px solid <?php echo $all_options_dynamik['rrac_button_border'] ?> !important; border-radius: <?php echo $all_options_dynamik['rrac_btn_border_radius'] ?>px !important;}

		.rrac_modal_container .apt_button a:hover, .rrac_modal_container .apt_button a:focus, .rrac_tabSection .tab-content .rrac_appt_btn a:hover, .rrac_tabSection .tab-content .rrac_appt_btn a:focus{background: <?php echo $all_options_dynamik['rrac_button_background_hover'] ?> !important; color:<?php echo $all_options_dynamik['rrac_button_text_hover'] ?> !important;}

		.rrac_tabSection .tab-content .rrac_appt_btn a:last-child{background:<?php echo $all_options_dynamik['rrac_secondary_button_background'] ?> !important;color: <?php echo $all_options_dynamik['rrac_secondary_button_text'] ?> !important;border: 1px solid <?php echo $all_options_dynamik['rrac_secondary_button_border'] ?> !important; border-radius: <?php echo $all_options_dynamik['rrac_btn_border_radius'] ?>px !important;}

		.rrac_tabSection .tab-content .rrac_appt_btn a:last-child:hover{background: <?php echo $all_options_dynamik['rrac_secondary_button_background_hover'] ?> !important; color:<?php echo $all_options_dynamik['rrac_secondary_button_text_hover'] ?> !important;}
		/******** modal**************/
		.rrac_modal_container .modal-body h3, #rrac_datepickerView .modal-header h4.modal-title{color: <?php echo $all_options_dynamik['rrac_modal_content_heading'] ?> !important;}
		
		.rrac_modal_container .apt_details_single_line span{color:<?php echo $all_options_dynamik['rrac_appartment_highlighted_text'] ?> !important;}
		.rrac_modal_container table, .rrac_modal_container table tr th, .rrac_modal_container table tr td{border-color:<?php echo $all_options_dynamik['rrac_modal_table_border'] ?> !important;}
		.ui-datepicker.move_in_date tr td.ui-datepicker-current-day .ui-state-active, .hasDatepicker tr td.ui-datepicker-current-day .ui-state-active{background: <?php echo $all_options_dynamik['rrac_modal_datepickert_active_background'] ?> !important;color: <?php echo $all_options_dynamik['rrac_modal_datepickert_active'] ?> !important;border: 1px solid #444 !important;}
		#rrac_datepickerView .leaseNowButton a{background: <?php echo $all_options_dynamik['rrac_modal_lease_now_button_background'] ?> !important;color: <?php echo $all_options_dynamik['rrac_modal_lease_now_button'] ?> !important;border: 1px solid #888 !important;}

		/***********Own(User) CSS***************/
		<?php echo $all_options_dynamik['rrac_own_css']; ?>

	</style>
	<!--------------Start RRAC Plugin CSS------------------>
    
    <?php

}
add_action( 'wp_head', 'my_dynamic_styles', 99 );
