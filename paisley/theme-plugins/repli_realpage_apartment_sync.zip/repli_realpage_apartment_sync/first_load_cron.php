<?php
	include('../../../wp-load.php');

	$result = false;
	$plugin_dir = ABSPATH.'wp-content/plugins/repli_realpage_apartment_sync/';
	$data =file_get_contents($plugin_dir.'first_load_data.json');

	if($data) {

		$data_array = json_decode($data,true);

		foreach ($data_array as $key => $value) {

			if($value['status'] == 1)
			{
				  $max_day = get_option('calendar_upcoming_days'); ////to get max date
				  $maxDate_by_api = date('Y-m-d', strtotime("+".$max_day." day", strtotime(date('Y-m-d'))));
				  $next_date = get_option('result_show_next_days');
				  $maxDate = date('Y-m-d', strtotime("+".$next_date." day", strtotime($value['moveindate'])));

				  if($maxDate > $maxDate_by_api) {
				    $maxDate =  $maxDate_by_api;
				  }

				  $RRAC_RP_API_USER = get_option('realpage_api_user');
				  $RRAC_RP_API_PASSWORD = get_option('realpage_api_password');
				  $RRAC_RP_API_SITEID = get_option('realpage_api_siteid');
				  $RRAC_RP_API_PMCID = get_option('realpage_api_pmcid');


			  // echo 'Floor Plan: '.$floorPlanID.'<br>';
			  //   echo 'Date: '.$maxDate.'<br>';

			  $xmlstr = '<?xml version="1.0" encoding="utf-8"?>
			    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
			      <soap12:Header>
			        <UserAuthInfo xmlns="http://realpage.com/webservices">
			          <UserName>'.$RRAC_RP_API_USER.'</UserName>
			          <Password>'.$RRAC_RP_API_PASSWORD.'</Password>
			          <SiteID>'.$RRAC_RP_API_SITEID.'</SiteID>
			          <PmcID>'.$RRAC_RP_API_PMCID.'</PmcID>
			          <InternalUser>'.$RRAC_RP_API_USER.'</InternalUser>
			        </UserAuthInfo>
			        
			      </soap12:Header>
			      <soap12:Body>
			        <List xmlns="http://realpage.com/webservices">
			          <listCriteria>
			            <ListCriterion>
			              <Name>FloorPlanID</Name>
			              <SingleValue>'.$value["floorplan_id"].'</SingleValue>
			            </ListCriterion>
			            <ListCriterion>
			              <Name>DateNeeded</Name>
			              <SingleValue>'.$maxDate.'</SingleValue>
			            </ListCriterion>
			            <ListCriterion>
			              <Name>LimitResults</Name>
			              <SingleValue>false</SingleValue>
			            </ListCriterion>
			            
			          </listCriteria>
			        </List>
			      </soap12:Body>
			    </soap12:Envelope>';

			    $url = 'http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/Unit.asmx';
			    $headers = array(
			    "POST: http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/Unit.asmx HTTP/1.1",
			    "Content-Type: application/soap+xml; charset=utf-8",
			    "Content-Length: ".strlen($xmlstr),
			    "Host: onesite.realpage.com"
			    );

			    $ch = curl_init();
			    curl_setopt($ch, CURLOPT_URL, $url);
			    curl_setopt($ch, CURLOPT_POST, true);
			    curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlstr);
			    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			    $response = curl_exec($ch);
			    $err = curl_error($ch);
			    curl_close($ch);

			    if ($err) {
			      echo "cURL Error #:" . $err;
			      $result['floor_plan_'.$value["floorplan_id"]] = $err;
			    } 
			    else 
			    {
			    	

			    	$response1 = str_replace("<soap:Body>","",$response);
				    $response2 = str_replace("</soap:Body>","",$response1);

				    $parser = simplexml_load_string($response2);

				    $result['floor_plan_'.$value["floorplan_id"]] = $parser;
				    $result['floor_plan_'.$value["floorplan_id"]]['available_date'] = $maxDate;

			    } 
			
			}

			if($result) {

				file_put_contents($plugin_dir.'first_load_response.json', "");

				file_put_contents($plugin_dir.'first_load_response.json', json_encode($result));

				//file_put_contents($plugin_dir.'first_load_response.txt', print_r($result, true));
			}

		}
	}

?>