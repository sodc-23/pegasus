<?php
//////////////Floor Plan List
function floorplan_list_by_id($floorplanID)
{
  
    $xmlstr = '<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <UserAuthInfo xmlns="http://realpage.com/webservices">
          <UserName>'.RRAC_RP_API_USER.'</UserName>
          <Password>'.RRAC_RP_API_PASSWORD.'</Password>
          <SiteID>'.RRAC_RP_API_SITEID.'</SiteID>
          <PmcID>'.RRAC_RP_API_PMCID.'</PmcID>
          <InternalUser>'.RRAC_RP_API_USER.'</InternalUser>
        </UserAuthInfo>
        
      </soap12:Header>
      <soap12:Body>
        <List xmlns="http://realpage.com/webservices">
          <listCriteria>
            <ListCriterion>
              <Name>FloorPlanID</Name>
              <SingleValue>'.$floorplanID.'</SingleValue>
            </ListCriterion>
            
          </listCriteria>
        </List>
      </soap12:Body>
    </soap12:Envelope>';

    $url = 'http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/FloorPlan.asmx';
    $headers = array(
    "POST: http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/FloorPlan.asmx HTTP/1.1",
    "Content-Type: application/soap+xml; charset=utf-8",
    "Content-Length: ".strlen($xmlstr),
    "Host: onesite.realpage.com"

    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlstr);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
      echo "cURL Error #:" . $err;
    }  
    //print_r($response); die;

    $response1 = str_replace("<soap:Body>","",$response);
    $response2 = str_replace("</soap:Body>","",$response1);

    $parser = simplexml_load_string($response2);

    return $parser;
}

//////////////

////////////GET PICK LIST
function getpicklists($listtype){
	$xmlstr = '<?xml version="1.0" encoding="utf-8"?>
		<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
		  <soap12:Header>
		    <UserAuthInfo xmlns="http://realpage.com/webservices">
		      <UserName>'.RRAC_RP_API_USER.'</UserName>
		      <Password>'.RRAC_RP_API_PASSWORD.'</Password>
		      <SiteID>'.RRAC_RP_API_SITEID.'</SiteID>
		      <PmcID>'.RRAC_RP_API_PMCID.'</PmcID>
		      <InternalUser>'.RRAC_RP_API_USER.'</InternalUser>
		    </UserAuthInfo>
		    
		  </soap12:Header>
		  <soap12:Body>
		    <GetPickLists xmlns="http://realpage.com/webservices">
		      <lTypes>
		      	 <ListType>'.$listtype.'</ListType>
		      </lTypes>
		    </GetPickLists>
		  </soap12:Body>
		</soap12:Envelope>';

		$url = 'http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/PickList.asmx';
		$headers = array(
		"POST: http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/PickList.asmx HTTP/1.1",
		"Content-Type: application/soap+xml; charset=utf-8",
		"Content-Length: ".strlen($xmlstr),
		"Host: onesite.realpage.com"
		);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlstr);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$response = curl_exec($ch);
		$err = curl_error($ch);
		curl_close($ch);

		if ($err) {
		  echo "cURL Error #:" . $err;
		}  
		//print_r($response); die;

		$response1 = str_replace("<soap:Body>","",$response);
		$response2 = str_replace("</soap:Body>","",$response1);

		$parser = simplexml_load_string($response2);
		return $parser;
}



////////////GET unit_list_by_floorPlanID
function unit_list_by_floorPlanID($floorPlanID , $moveindate){ 
  //$minDate = date('Y-m-d', strtotime("-7 day", strtotime($moveindate)));

    
 // die();

  $max_day = CALENDAR_UPCOMING_DAYS; ////to get max date
  $maxDate_by_api = date('Y-m-d', strtotime("+".$max_day." day", strtotime(date('Y-m-d'))));

  $maxDate = date('Y-m-d', strtotime("+".RESULT_SHOW_NEXT_DAYS." day", strtotime($moveindate)));
  if($maxDate > $maxDate_by_api)
  {
    $maxDate =  $maxDate_by_api;
  }

  // echo 'Floor Plan: '.$floorPlanID.'<br>';
  //   echo 'Date: '.$maxDate.'<br>';

  $xmlstr = '<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <UserAuthInfo xmlns="http://realpage.com/webservices">
          <UserName>'.RRAC_RP_API_USER.'</UserName>
          <Password>'.RRAC_RP_API_PASSWORD.'</Password>
          <SiteID>'.RRAC_RP_API_SITEID.'</SiteID>
          <PmcID>'.RRAC_RP_API_PMCID.'</PmcID>
          <InternalUser>'.RRAC_RP_API_USER.'</InternalUser>
        </UserAuthInfo>
        
      </soap12:Header>
      <soap12:Body>
        <List xmlns="http://realpage.com/webservices">
          <listCriteria>
            <ListCriterion>
              <Name>FloorPlanID</Name>
              <SingleValue>'.$floorPlanID.'</SingleValue>
            </ListCriterion>
            <ListCriterion>
              <Name>DateNeeded</Name>
              <SingleValue>'.$maxDate.'</SingleValue>
            </ListCriterion>
            <ListCriterion>
              <Name>LimitResults</Name>
              <SingleValue>false</SingleValue>
            </ListCriterion>
            
          </listCriteria>
        </List>
      </soap12:Body>
    </soap12:Envelope>';

    $url = 'http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/Unit.asmx';
    $headers = array(
    "POST: http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/Unit.asmx HTTP/1.1",
    "Content-Type: application/soap+xml; charset=utf-8",
    "Content-Length: ".strlen($xmlstr),
    "Host: onesite.realpage.com"
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlstr);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
      echo "cURL Error #:" . $err;
    }  
    //print_r($response); die;

    $response1 = str_replace("<soap:Body>","",$response);
    $response2 = str_replace("</soap:Body>","",$response1);

    $parser = simplexml_load_string($response2);

//echo "<pre>";print_r($response2);

    return $parser;
}


////////////GET unit_list
function rrac_get_unit_list($bedroom = '' , $floorplan_id = ''){ 
  //$minDate = date('Y-m-d', strtotime("-7 day", strtotime($moveindate)));

  $max_day = CALENDAR_UPCOMING_DAYS; ////to get max date
  $maxDate_by_api = date('Y-m-d', strtotime("+".$max_day." day", strtotime(date('Y-m-d'))));
  
  $maxDate =  $maxDate_by_api;
  
  $xmlstr = '<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <UserAuthInfo xmlns="http://realpage.com/webservices">
          <UserName>'.RRAC_RP_API_USER.'</UserName>
          <Password>'.RRAC_RP_API_PASSWORD.'</Password>
          <SiteID>'.RRAC_RP_API_SITEID.'</SiteID>
          <PmcID>'.RRAC_RP_API_PMCID.'</PmcID>
          <InternalUser>'.RRAC_RP_API_USER.'</InternalUser>
        </UserAuthInfo>
        
      </soap12:Header>
      <soap12:Body>
        <List xmlns="http://realpage.com/webservices">
          <listCriteria>
            
            <ListCriterion>
              <Name>DateNeeded</Name>
              <SingleValue>'.$maxDate.'</SingleValue>
            </ListCriterion>';
  if($bedroom != '')
  {
    $xmlstr .= '<ListCriterion>
              <Name>NumberBedrooms</Name>
              <SingleValue>'.$bedroom.'</SingleValue>
            </ListCriterion>';
  }
  if($floorplan_id != '')
  {
    $xmlstr .= '<ListCriterion>
              <Name>FloorPlanID</Name>
              <SingleValue>'.$floorplan_id.'</SingleValue>
            </ListCriterion>';
  }
  $xmlstr .= '<ListCriterion>
              <Name>LimitResults</Name>
              <SingleValue>false</SingleValue>
            </ListCriterion>
            
          </listCriteria>
        </List>
      </soap12:Body>
    </soap12:Envelope>';

    $url = 'http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/Unit.asmx';
    $headers = array(
    "POST: http://onesite.realpage.com/WebServices/CrossFire/AvailabilityAndPricing/Unit.asmx HTTP/1.1",
    "Content-Type: application/soap+xml; charset=utf-8",
    "Content-Length: ".strlen($xmlstr),
    "Host: onesite.realpage.com"
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlstr);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
      echo "cURL Error #:" . $err;
    }  
    //print_r($response); die;

    $response1 = str_replace("<soap:Body>","",$response);
    $response2 = str_replace("</soap:Body>","",$response1);

    $parser = simplexml_load_string($response2);
    return $parser;
}

?>